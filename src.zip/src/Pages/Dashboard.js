import React, { useContext } from 'react';
import { AuthContext } from '../context/Auth.context.js';

import { Route, Routes } from 'react-router-dom';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  const { logout } = useContext(AuthContext);
  const onLogout = (e) => {
    e.preventDefault();
    logout();
  }

    return (

      <div className="row">
        <div className="col-sm-8 ml-80 ">
        
          <h1>
            Hello Admin
          </h1>
          
        </div>
        {/* <div className="ml-80"><Link </Link></div> */}
        
       
  
    </div>
  
    );
  
  }
  
  export default Dashboard;