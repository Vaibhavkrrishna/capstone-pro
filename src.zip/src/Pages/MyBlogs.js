import React from 'react'

export default function MyBlogs() {
  return (
    <div className='ml-96'>MyBlogs</div>
  )
}
