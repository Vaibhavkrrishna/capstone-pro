import React, { useEffect, useState } from 'react'

export default function Card() {
    let url= 'http://localhost:3000/users'

    let [post,setPost]=useState([])

    

    
    let[loading,SetLOading]=useState(true)

    let getAllPost= async ()=>{

        let response= await fetch(url)

        let data= await response.json()

        setPost(data)
        SetLOading(false)

    }
        useEffect(()=>{
            getAllPost()
        },[])
        
  return (
    <div >
         <div >
      {loading? ("Fetching Blogs"):(
        post.map((post)=>{
          return(
            <div className=' p-10 grid grid-cols-1 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 gap-5' >
             <div className='rounded overflow-hidden shadow-lg'>
              <img alt="Blog post"/> 
              {/* image should be included here */}
              <div className='px-6 py-4'>
              <div class="font-bold text-xl mb-2">{post.title}</div>
              <p class="text-gray-700 text-base">
                {post.summary}
              </p>
              </div>
              </div>   
            
            </div>
          )
        })
      )}
    </div>
    </div>
  )
}
