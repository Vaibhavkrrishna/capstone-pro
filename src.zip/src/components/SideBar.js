import React from 'react'
import { useContext } from 'react';
import { AuthContext } from '../context/Auth.context.js';
import {Link} from 'react-router-dom'
import NewPost from '../Pages/NewPost.js';
import MyBlogs from '../Pages/MyBlogs.js';
export default function SideBar() {
    const { logout } = useContext(AuthContext);
    const onLogout = (e) => {
      e.preventDefault();
      logout();
    }
    function handleMyBlogs(){
      return(
        <MyBlogs/>

      )

    }
    function handleCreatePost(){
      return(
        <NewPost/>

      )

    }
  return (
    <div className=" h-16 bg-black fixed  shadow-lg font-mono h-full w-32 ">
    {/* <header  className="flex h-14 max-w-7xl  justify-between "> */}
         <div className='ml-5 mt-5 flex flex-col justify-between  '>
          <Link to="/">
          <div title="Home">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth="1.5"
              stroke="currentColor"
              className="w-8 h-8 text-slate-500 text-white mt-36 ml-7 hover:bg-slate-400"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"
               
              />
            </svg>
    </div>
          </Link>
          <Link to="/myblogs" onClick={handleMyBlogs}>
          <div title="My blogs">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" className="w-8 h-8 text-white mt-20 ml-7 hover:bg-slate-400">
  <path stroke-linecap="round" stroke-linejoin="round" d="M16.5 8.25V6a2.25 2.25 0 00-2.25-2.25H6A2.25 2.25 0 003.75 6v8.25A2.25 2.25 0 006 16.5h2.25m8.25-8.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-7.5A2.25 2.25 0 018.25 18v-1.5m8.25-8.25h-6a2.25 2.25 0 00-2.25 2.25v6" />
</svg>
</div>
</Link>
<Link to='/newpost' onClick={()=>handleCreatePost}>
  <div title="Create new blog">
          <svg  xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" className=" w-8 h-8 text-white mt-20 ml-7 hover:alt-hello hover:bg-slate-400">
  <path stroke-linecap="round" stroke-linejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />
</svg>
</div>
</Link>
<div className="col-sm-4 mt-20 text-white text-2xl ">
          <h1>
            <Link to='/login'><button onClick={onLogout}>Logout</button></Link>
          </h1>

        </div>
       
  
        </div>
    {/* </header> */}
    </div>
  )
}
